"use client";
import "./chunk-C6WWHQR7.js";
import {
  createSvgIcon
} from "./chunk-XTJYQ4ZC.js";
import {
  require_jsx_runtime
} from "./chunk-SP47HHOX.js";
import "./chunk-YLDSBLSF.js";
import {
  __toESM
} from "./chunk-DC5AMYBS.js";

// node_modules/@mui/icons-material/esm/Bookmark.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var Bookmark_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2"
}), "Bookmark");
export {
  Bookmark_default as default
};
//# sourceMappingURL=@mui_icons-material_Bookmark.js.map
