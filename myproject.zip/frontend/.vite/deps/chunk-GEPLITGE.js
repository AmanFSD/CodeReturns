import {
  identifier_default,
  unstable_createUseMediaQuery
} from "./chunk-SP47HHOX.js";

// node_modules/@mui/material/useMediaQuery/index.js
var useMediaQuery = unstable_createUseMediaQuery({
  themeId: identifier_default
});
var useMediaQuery_default = useMediaQuery;

export {
  useMediaQuery_default
};
//# sourceMappingURL=chunk-GEPLITGE.js.map
