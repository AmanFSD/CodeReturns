import {
  useMediaQuery_default
} from "./chunk-GEPLITGE.js";
import "./chunk-SP47HHOX.js";
import "./chunk-YLDSBLSF.js";
import "./chunk-DC5AMYBS.js";
export {
  useMediaQuery_default as default
};
