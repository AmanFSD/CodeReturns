import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Box, Container, CircularProgress, Typography, Button } from "@mui/material";
import CourseVideoSection from "../components/CourseVideoSection";
import CourseContentDetails from "../components/CourseContentDetails";
import CourseReviews from "../components/CourseReviews";

const CourseDetailPage: React.FC = () => {
  const { courseId } = useParams<{ courseId?: string }>(); // ✅ Typed param
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  console.log("Extracted Course ID from URL:", courseId); // Debug log

  useEffect(() => {
    if (!courseId) {
      setError("Course ID is missing from the URL.");
      setLoading(false);
      return;
    }

    axios
      .get(`http://localhost:8000/api/courses/${courseId}/`)
      .then((response) => {
        if (response.data) {
          setCourse(response.data);
        } else {
          setError("No course data found.");
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching course:", error);
        setError("Failed to load course. Please try again later.");
        setLoading(false);
      });
  }, [courseId]);

  if (loading) return (
    <Container sx={{ textAlign: "center", mt: 10 }}>
      <CircularProgress />
      <Typography variant="h6" mt={2}>Loading course details...</Typography>
    </Container>
  );

  if (error) return (
    <Container sx={{ textAlign: "center", mt: 10 }}>
      <Typography variant="h6" color="error">{error}</Typography>
      <Button variant="outlined" onClick={() => window.location.reload()}>Retry</Button>
    </Container>
  );

  return (
    <Box sx={{ width: "100%", overflowY: "auto" }}>
      <Container maxWidth="xl">
        <CourseVideoSection course={course} />
        <CourseContentDetails course={course} />
        <CourseReviews courseId={courseId!} />
      </Container>
    </Box>
  );
};

export default CourseDetailPage;