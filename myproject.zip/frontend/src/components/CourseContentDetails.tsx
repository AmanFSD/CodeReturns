import React from "react";
import { Box, Typography, Paper, Rating } from "@mui/material";

const CourseContentDetails: React.FC<{ course: any }> = ({ course }) => (
  <Paper sx={{ my: 4, p: 3, height: '90vh', overflowY: 'auto' }}>
    <Typography variant="h5" fontWeight="bold">{course.title}</Typography>

    <Box sx={{ my: 2 }}>
      <Rating value={4.7} precision={0.1} readOnly />
      <Typography variant="body2">{course.enrolled_count ?? "N/A"} enrolled • {course.duration ?? "N/A"} Hours</Typography>
    </Box>

    <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
      {course.description}
    </Typography>
  </Paper>
);

export default CourseContentDetails;